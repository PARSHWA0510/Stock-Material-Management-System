#!/bin/sh
set -e

echo "🚀 Starting Stock Management Backend..."

# Wait for database to be ready (if using external DB)
if [ -n "$DATABASE_URL" ]; then
  echo "📊 Checking database connection..."
  until npx prisma db execute --stdin <<< "SELECT 1" > /dev/null 2>&1; do
    echo "⏳ Waiting for database..."
    sleep 2
  done
  echo "✅ Database connected"
fi

# Run migrations
echo "🔄 Running database migrations..."
npx prisma migrate deploy || echo "⚠️  Migration failed or already up to date"

# Start the application
echo "🚀 Starting server..."
exec node dist/index.js

