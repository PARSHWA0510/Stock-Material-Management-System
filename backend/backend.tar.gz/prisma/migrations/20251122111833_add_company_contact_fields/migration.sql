-- AlterTable
ALTER TABLE "companies" ADD COLUMN     "contact_person" TEXT,
ADD COLUMN     "email_id" TEXT,
ADD COLUMN     "mobile_number" TEXT;
